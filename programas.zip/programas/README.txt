INSTRUÇÕES!
Na pasta PVI contém um único programa principal e um único módulo para resolver os 5 problemas
O programa está configurado para resolver o problema5, 
para utilizar basta compilar o código da linha 1.

Para escolher outro problema basta seguir os passos:
1) Alterar o nome do problema nas linhas 14 e 38
2) Utilizar o código de compilação do respectivo problema disponível nas linhas de 1 a 5
